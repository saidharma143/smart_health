package com.example.smarthealth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Launcher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
       /* try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Intent MainActivityNavintent=new Intent(Launcher.this,MainActivityNav.class);
        startActivity(MainaActivityNavintent);*/
        Thread thread=  new Thread(){
            @Override
            public void run(){
                try {
                    synchronized (this){
                        wait(50000);

                    }
                }
                catch(InterruptedException ex){
                }
                MainActivityNav.setOnClickListener(new  View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(Launcher.this, MainActivityNav.class);
                        startActivity(intent);
                    }
                });

            }
        };

    }
}
