package com.example.smarthealth;

import android.app.Activity;

public class Lander extends Activity {
}
